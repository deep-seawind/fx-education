import axios from "axios";
import React, { useState } from "react";
import toast from "react-hot-toast";
import { BiUser, BiEnvelope, BiLockAlt, BiChevronRight } from "react-icons/bi";
import { z } from "zod";

const signupSchema = z.object({
  firstName: z.string().min(2, "First name is required"),
  lastName: z.string().min(2, "Last name is required"),
  email: z.string().email("Enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  terms: z.literal(true, {
    errorMap: () => ({ message: "You must accept the terms" }),
  }),
});
const SigForm = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    terms: false,
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  /* -------------------- HANDLE CHANGE -------------------- */
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });

    setErrors({ ...errors, [name]: "" });
  };

  /* -------------------- HANDLE SUBMIT -------------------- */
  const handleSubmit = async (e) => {
    e.preventDefault();

    const validation = signupSchema.safeParse(formData);

    if (!validation.success) {
      const fieldErrors = {};
      validation.error.issues.forEach((err) => {
        fieldErrors[err.path[0]] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }

    setErrors({});

    try {
      setLoading(true);

      await axios.post("http://localhost:5000/api/auth/register", formData, {
        headers: { "Content-Type": "application/json" },
      });

      toast.success("Registration successful 🚀");

      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        terms: false,
      });
      
    } catch (error) {
      toast.error(error.response?.data?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <form className="space-y-6" onSubmit={handleSubmit}>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-[10px] font-semibold uppercase tracking-widest text-slate-400 ml-1 pb-2">
              First Name
            </label>
            <div className="relative group">
              <BiUser className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-color transition-colors" />
              <input
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                type="text"
                placeholder="Alexander"
                className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-hidden focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all font-medium text-slate-900 mt-2"
              />
              {errors.firstName && (
                <p className="text-red-500 text-xs mt-1">{errors.firstName}</p>
              )}
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-semibold uppercase tracking-widest text-slate-400 ml-1">
              Last Name
            </label>
            <input
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              type="text"
              placeholder="Pierce"
              className="w-full px-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-hidden focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all font-medium text-slate-900 mt-2"
            />{" "}
            {errors.lastName && (
              <p className="text-red-500 text-xs mt-1">{errors.lastName}</p>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-semibold uppercase tracking-widest text-slate-400 ml-1">
            Email Address
          </label>
          <div className="relative group">
            <BiEnvelope className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-color transition-colors" />
            <input
              name="email"
              value={formData.email}
              onChange={handleChange}
              type="email"
              placeholder="alex@institutional.com"
              className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-hidden focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all font-medium text-slate-900 mt-2"
            />
            {errors.email && (
              <p className="text-red-500 text-xs mt-1">{errors.email}</p>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-semibold uppercase tracking-widest text-slate-400 ml-1">
            Security Password
          </label>
          <div className="relative group">
            <BiLockAlt className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-color transition-colors" />
            <input
              name="password"
              value={formData.password}
              onChange={handleChange}
              type="password"
              placeholder="••••••••"
              className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-hidden focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all font-medium text-slate-900 mt-2"
            />
            {errors.password && (
              <p className="text-red-500 text-xs mt-1">{errors.password}</p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 py-2">
          <input
            type="checkbox"
            className="w-5 h-5 rounded-lg border-slate-200 text-color focus:ring-indigo-500"
            name="terms"
            value={formData.terms}
            onChange={handleChange}
          />

          <p className="text-sm text-slate-500 font-medium">
            I agree to the{" "}
            <span className="text-color font-semibold hover:underline cursor-pointer">
              Terms of Service
            </span>
          </p>
          {errors.terms && (
            <p className="text-red-500 text-xs">{errors.terms}</p>
          )}
        </div>

        <button className="w-1/2 py-5 bg-slate-900 text-white rounded-3xl font-semibold flex items-center justify-center gap-3 group hover:bg-color transition-all shadow-xl shadow-slate-200 active:scale-[0.98]">
          {loading ? "Creating Account..." : "Complete Registration"}
          <BiChevronRight className="text-2xl group-hover:translate-x-1 transition-transform" />
        </button>
      </form>
    </>
  );
};

export default SigForm;
