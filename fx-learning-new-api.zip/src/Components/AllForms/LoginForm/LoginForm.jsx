import React, { useState } from "react";
import { BiEnvelope, BiLockAlt, BiChevronRight } from "react-icons/bi";
import axios from "axios";
import toast from "react-hot-toast";
import { z } from "zod";

// --------------------- ZOD SCHEMA ---------------------
const loginSchema = z.object({
  email: z.string().email({ message: "Enter a valid email" }),
  password: z
    .string()
    .min(6, { message: "Password must be at least 6 characters" }),
});

const LoginForm = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});


const handleChange = (e) => {
  setFormData({
    ...formData,
    [e.target.name]: e.target.value,
  });

  setErrors({
    ...errors,
    [e.target.name]: "",
  });
};


const handleSubmit = async (e) => {
  e.preventDefault();

  const validation = loginSchema.safeParse(formData);

  if (!validation.success) {
    const fieldErrors = {};

    validation.error.issues.forEach((err) => {
      fieldErrors[err.path[0]] = err.message;
    });

    setErrors(fieldErrors);
    return;
  }

  setErrors({});

  try {
    setLoading(true);

    const res = await axios.post(
      "http://localhost:5000/api/auth/login",
      formData,
      { headers: { "Content-Type": "application/json" } }
    );

    localStorage.setItem("token", res.data.token);
    toast.success("Login successful 🚀");

  } catch (error) {
    toast.error(error.response?.data?.message || "Login failed");
  } finally {
    setLoading(false);
  }
};

  return (
    <form className="space-y-6" onSubmit={handleSubmit}>
      {/* EMAIL */}
      <div className="space-y-2">
        <label className="text-[10px] font-semibold uppercase tracking-widest text-slate-400 ml-1">
          Account Email
        </label>
        <div className="relative group">
          <BiEnvelope className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-color transition-colors" />
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="trader@institutional.com"
            className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all font-medium text-slate-900 mt-2"
          />
        </div>
        {errors.email && (
  <p className="text-red-500 text-xs mt-1 ml-1">
    {errors.email}
  </p>
)}

      </div>

      {/* PASSWORD */}
      <div className="space-y-2">
        <div className="flex justify-between items-center px-1">
          <label className="text-[10px] font-semibold uppercase tracking-widest text-slate-400">
            Security Password
          </label>
          <span className="text-[10px] font-semibold text-color cursor-pointer hover:underline">
            Forgot?
          </span>
        </div>
        <div className="relative group">
          <BiLockAlt className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-color transition-colors" />
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="••••••••"
            className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all font-medium text-slate-900 mt-2"
          />
        </div>
        {errors.password && (
  <p className="text-red-500 text-xs mt-1 ml-1">
    {errors.password}
  </p>
)}

      </div>

      {/* SUBMIT */}
      <button
        type="submit"
        disabled={loading}
        className="w-1/2 py-5 bg-slate-900 text-white rounded-3xl font-semibold flex items-center justify-center gap-3 group hover:bg-color transition-all shadow-xl shadow-slate-200 active:scale-[0.98] disabled:opacity-60"
      >
        {loading ? "Authenticating..." : "Initialize Terminal"}
        <BiChevronRight className="text-2xl group-hover:translate-x-1 transition-transform" />
      </button>
    </form>
  );
};

export default LoginForm;
